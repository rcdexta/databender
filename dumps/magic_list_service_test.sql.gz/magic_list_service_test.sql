-- MySQL dump 10.13  Distrib 5.7.19, for osx10.13 (x86_64)
--
-- Host: 127.0.0.1    Database: magic_list_service_test_subset
-- ------------------------------------------------------
-- Server version	5.7.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer_fingerprint`
--

DROP TABLE IF EXISTS `customer_fingerprint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_fingerprint` (
  `id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `quote_version_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `metadata` text COLLATE utf8_unicode_ci,
  `created_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_fingerprint`
--

LOCK TABLES `customer_fingerprint` WRITE;
/*!40000 ALTER TABLE `customer_fingerprint` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_fingerprint` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `magic_list_item_human_recommendations`
--

DROP TABLE IF EXISTS `magic_list_item_human_recommendations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `magic_list_item_human_recommendations` (
  `magic_list_item_human_recommendation_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `magic_list_item_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `recommended_sku_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `created_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`magic_list_item_human_recommendation_id`),
  KEY `fk_magic_list_item_human_recommendations_to_magic_list_item_idx` (`magic_list_item_id`),
  CONSTRAINT `fk_magic_list_item_human_recommendations_to_magic_list_items` FOREIGN KEY (`magic_list_item_id`) REFERENCES `magic_list_items` (`magic_list_item_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `magic_list_item_human_recommendations`
--

LOCK TABLES `magic_list_item_human_recommendations` WRITE;
/*!40000 ALTER TABLE `magic_list_item_human_recommendations` DISABLE KEYS */;
/*!40000 ALTER TABLE `magic_list_item_human_recommendations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `magic_list_item_search_skus`
--

DROP TABLE IF EXISTS `magic_list_item_search_skus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `magic_list_item_search_skus` (
  `magic_list_item_search_sku_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `magic_list_item_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `sku_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `sku_name` mediumtext COLLATE utf8_unicode_ci,
  `answer_text` mediumtext COLLATE utf8_unicode_ci,
  `answer_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`magic_list_item_search_sku_id`),
  KEY `fk_magic_list_items_search_skus_to_magic_list_items_idx` (`magic_list_item_id`),
  CONSTRAINT `fk_magic_list_items_search_skus_to_magic_list_items` FOREIGN KEY (`magic_list_item_id`) REFERENCES `magic_list_items` (`magic_list_item_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `magic_list_item_search_skus`
--

LOCK TABLES `magic_list_item_search_skus` WRITE;
/*!40000 ALTER TABLE `magic_list_item_search_skus` DISABLE KEYS */;
/*!40000 ALTER TABLE `magic_list_item_search_skus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `magic_list_items`
--

DROP TABLE IF EXISTS `magic_list_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `magic_list_items` (
  `magic_list_item_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `magic_list_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `parent_magic_list_item_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `search_expression` mediumtext COLLATE utf8_unicode_ci,
  `sku_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `answer_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `original_sku_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `original_answer_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sku_match_status` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `complexity_index` int(11) DEFAULT '0',
  `uom_type` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uom_quantity` int(10) unsigned DEFAULT NULL,
  `uom_length` int(10) unsigned DEFAULT NULL,
  `uom_width` int(10) unsigned DEFAULT NULL,
  `uom_height` int(11) DEFAULT NULL,
  `order_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `service_request_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `referral_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `low_estimate` double DEFAULT NULL,
  `high_estimate` double DEFAULT NULL,
  `is_fixed_price` tinyint(1) DEFAULT '0',
  `price_basis_description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_guaranteed` tinyint(1) DEFAULT '0',
  `active_human_recommendation_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin_notes` mediumtext COLLATE utf8_unicode_ci,
  `sort_order` int(11) DEFAULT '0',
  `created_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`magic_list_item_id`),
  KEY `fk_magic_list_items_to_magic_list_idx` (`magic_list_id`),
  KEY `fk_magic_list_items_to_parent_magic_list_item_idx` (`parent_magic_list_item_id`),
  CONSTRAINT `fk_magic_list_items_to_magic_list` FOREIGN KEY (`magic_list_id`) REFERENCES `magic_lists` (`magic_list_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `magic_list_items`
--

LOCK TABLES `magic_list_items` WRITE;
/*!40000 ALTER TABLE `magic_list_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `magic_list_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `magic_lists`
--

DROP TABLE IF EXISTS `magic_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `magic_lists` (
  `magic_list_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `short_id` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `customer_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `session_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_test_list` tinyint(1) DEFAULT '0',
  `admin_notes` mediumtext COLLATE utf8_unicode_ci,
  `customer_label` mediumtext COLLATE utf8_unicode_ci,
  `zip_code` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `preferred_service_provider_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `etag` int(11) NOT NULL DEFAULT '0',
  `created_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `has_offers` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`magic_list_id`),
  UNIQUE KEY `short_id_UNIQUE` (`short_id`),
  KEY `idx_ml_customer_id_and_status` (`customer_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `magic_lists`
--

LOCK TABLES `magic_lists` WRITE;
/*!40000 ALTER TABLE `magic_lists` DISABLE KEYS */;
/*!40000 ALTER TABLE `magic_lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quote_change_requests`
--

DROP TABLE IF EXISTS `quote_change_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quote_change_requests` (
  `id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `quote_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `quote_version_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `resolution_quote_version_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `est_hours` decimal(8,3) DEFAULT NULL,
  `est_materials_cost` decimal(8,2) DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `created_by` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `due_time` datetime DEFAULT NULL,
  `created_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_time` datetime NOT NULL,
  `cancellation_reason` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `fk_quote_cr_quote_id_idx` (`quote_id`),
  KEY `fk_quote_cr_ingress_quote_version_id_idx` (`quote_version_id`),
  KEY `fk_quote_cr_resolution_quote_version_id_idx` (`resolution_quote_version_id`),
  CONSTRAINT `fk_quote_cr_ingress_quote_version_id` FOREIGN KEY (`quote_version_id`) REFERENCES `quote_versions` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_quote_cr_quote_id` FOREIGN KEY (`quote_id`) REFERENCES `quotes` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_quote_cr_resolution_quote_version_id` FOREIGN KEY (`resolution_quote_version_id`) REFERENCES `quote_versions` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quote_change_requests`
--

LOCK TABLES `quote_change_requests` WRITE;
/*!40000 ALTER TABLE `quote_change_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `quote_change_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quote_metadata`
--

DROP TABLE IF EXISTS `quote_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quote_metadata` (
  `id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `quote_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `customer_first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `customer_last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `customer_email_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_quote` (`quote_id`),
  CONSTRAINT `quote_metadata_ibfk_1` FOREIGN KEY (`quote_id`) REFERENCES `quotes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quote_metadata`
--

LOCK TABLES `quote_metadata` WRITE;
/*!40000 ALTER TABLE `quote_metadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `quote_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quote_notes`
--

DROP TABLE IF EXISTS `quote_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quote_notes` (
  `id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `quote_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `author` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `created_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quote_notes`
--

LOCK TABLES `quote_notes` WRITE;
/*!40000 ALTER TABLE `quote_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `quote_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quote_subcontractor_appointment_alerts`
--

DROP TABLE IF EXISTS `quote_subcontractor_appointment_alerts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quote_subcontractor_appointment_alerts` (
  `id` varchar(40) NOT NULL,
  `service_provider_id` varchar(255) DEFAULT NULL,
  `order_id` varchar(40) DEFAULT NULL,
  `estimate_appointment_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `appointment_reminder_status` varchar(255) NOT NULL,
  `appointment_reminder_due_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `quote_submission_request_status` varchar(255) NOT NULL,
  `count_quote_submission_requests` int(11) DEFAULT NULL,
  `initial_quote_prompt_trigger_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `latest_quote_prompt_sent_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(255) DEFAULT NULL,
  `created_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `service_request_id` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quote_subcontractor_appointment_alerts`
--

LOCK TABLES `quote_subcontractor_appointment_alerts` WRITE;
/*!40000 ALTER TABLE `quote_subcontractor_appointment_alerts` DISABLE KEYS */;
/*!40000 ALTER TABLE `quote_subcontractor_appointment_alerts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quote_version_download_history`
--

DROP TABLE IF EXISTS `quote_version_download_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quote_version_download_history` (
  `id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `quote_version_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `pdf_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `shared_with_customer` tinyint(1) DEFAULT '0',
  `downloaded_by` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `created_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `download_history_version_id_idx` (`quote_version_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quote_version_download_history`
--

LOCK TABLES `quote_version_download_history` WRITE;
/*!40000 ALTER TABLE `quote_version_download_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `quote_version_download_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quote_version_line_items`
--

DROP TABLE IF EXISTS `quote_version_line_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quote_version_line_items` (
  `id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `quote_version_section_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `price_type` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `material_sourcing` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `item_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` text COLLATE utf8_unicode_ci,
  `labor_trade_id` int(11) DEFAULT NULL,
  `unit_price` double DEFAULT NULL,
  `uom_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uom_quantity` double DEFAULT NULL,
  `sort_order` double DEFAULT NULL,
  `mark_up_percent` double DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `total_price` double DEFAULT NULL,
  `created_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `fixed_price` double DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `line_item_price` double DEFAULT NULL,
  `lifetime_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `completion_status` varchar(15) COLLATE utf8_unicode_ci DEFAULT 'NEW',
  `special_order` tinyint(1) DEFAULT '0',
  `customer_provided` tinyint(1) DEFAULT '0',
  `measurement_required` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_plan` (`quote_version_section_id`),
  CONSTRAINT `quote_version_line_items_ibfk_1` FOREIGN KEY (`quote_version_section_id`) REFERENCES `quote_version_sections` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quote_version_line_items`
--

LOCK TABLES `quote_version_line_items` WRITE;
/*!40000 ALTER TABLE `quote_version_line_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `quote_version_line_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quote_version_sections`
--

DROP TABLE IF EXISTS `quote_version_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quote_version_sections` (
  `id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `title` text COLLATE utf8_unicode_ci,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `total_price` double DEFAULT NULL,
  `quote_version_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `magic_list_item_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price_type` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sort_order` double DEFAULT NULL,
  `fixed_price` double DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `line_item_price` double DEFAULT NULL,
  `lifetime_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_version` (`quote_version_id`),
  KEY `fk_ml_item` (`magic_list_item_id`),
  CONSTRAINT `quote_version_sections_ibfk_1` FOREIGN KEY (`quote_version_id`) REFERENCES `quote_versions` (`id`),
  CONSTRAINT `quote_version_sections_ibfk_2` FOREIGN KEY (`magic_list_item_id`) REFERENCES `magic_list_items` (`magic_list_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quote_version_sections`
--

LOCK TABLES `quote_version_sections` WRITE;
/*!40000 ALTER TABLE `quote_version_sections` DISABLE KEYS */;
/*!40000 ALTER TABLE `quote_version_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quote_version_status_history`
--

DROP TABLE IF EXISTS `quote_version_status_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quote_version_status_history` (
  `id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `quote_version_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quote_version_status_history`
--

LOCK TABLES `quote_version_status_history` WRITE;
/*!40000 ALTER TABLE `quote_version_status_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `quote_version_status_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quote_versions`
--

DROP TABLE IF EXISTS `quote_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quote_versions` (
  `id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `quote_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `previous_version_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` text COLLATE utf8_unicode_ci,
  `estimator_notes` text COLLATE utf8_unicode_ci,
  `low_estimate` double DEFAULT NULL,
  `high_estimate` double DEFAULT NULL,
  `file_location` text COLLATE utf8_unicode_ci,
  `customer_shared_time` datetime DEFAULT NULL,
  `customer_signed_time` datetime DEFAULT NULL,
  `approval_time` datetime DEFAULT NULL,
  `created_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `total_price` double DEFAULT NULL,
  `fixed_price` double DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `line_item_price` double DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lifetime_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `short_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `has_work_appointment_scheduled` tinyint(1) DEFAULT '0',
  `work_appointment_updated_at` datetime DEFAULT NULL,
  `completion_status` varchar(15) COLLATE utf8_unicode_ci DEFAULT 'NEW',
  `special_order` tinyint(1) DEFAULT '0',
  `submitted_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `work_order_notes` text COLLATE utf8_unicode_ci,
  `rate_contracted` tinyint(1) DEFAULT '0',
  `tools_required` tinyint(1) DEFAULT '0',
  `measurements_required` tinyint(1) DEFAULT '0',
  `should_compute_tax` tinyint(1) DEFAULT '1',
  `mark_up_percentage` double DEFAULT NULL,
  `accepted_by` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_quote` (`quote_id`),
  CONSTRAINT `quote_versions_ibfk_1` FOREIGN KEY (`quote_id`) REFERENCES `quotes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quote_versions`
--

LOCK TABLES `quote_versions` WRITE;
/*!40000 ALTER TABLE `quote_versions` DISABLE KEYS */;
/*!40000 ALTER TABLE `quote_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotes`
--

DROP TABLE IF EXISTS `quotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quotes` (
  `id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `magic_list_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `service_request_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `zip_code` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `zip_code_multiplier` double DEFAULT NULL,
  `business_unit_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estimator` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reviewer` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `customer_notes` text COLLATE utf8_unicode_ci,
  `estimator_notes` text COLLATE utf8_unicode_ci,
  `current_quote_version_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `bid_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `conversation_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `customer_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `short_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `communication_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `eta` date DEFAULT NULL,
  `latest_shared_version_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `labor_tax_rate` double DEFAULT NULL,
  `material_tax_rate` double DEFAULT NULL,
  `latest_accepted_version_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `triage_status` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'UNTRIAGED',
  `triaging_user_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `triaged_at` datetime DEFAULT NULL,
  `job_manager` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `project_manager` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sales_manager` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `quotes_idx_by_customer_id` (`customer_id`),
  KEY `quotes_idx_by_sr_id` (`service_request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotes`
--

LOCK TABLES `quotes` WRITE;
/*!40000 ALTER TABLE `quotes` DISABLE KEYS */;
/*!40000 ALTER TABLE `quotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_version`
--

DROP TABLE IF EXISTS `schema_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schema_version` (
  `version_rank` int(11) NOT NULL,
  `installed_rank` int(11) NOT NULL,
  `version` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `type` varchar(20) NOT NULL,
  `script` varchar(1000) NOT NULL,
  `checksum` int(11) DEFAULT NULL,
  `installed_by` varchar(100) NOT NULL,
  `installed_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `execution_time` int(11) NOT NULL,
  `success` tinyint(1) NOT NULL,
  PRIMARY KEY (`version`),
  KEY `schema_version_vr_idx` (`version_rank`),
  KEY `schema_version_ir_idx` (`installed_rank`),
  KEY `schema_version_s_idx` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_version`
--

LOCK TABLES `schema_version` WRITE;
/*!40000 ALTER TABLE `schema_version` DISABLE KEYS */;
/*!40000 ALTER TABLE `schema_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subcontractor_dispatch_requests`
--

DROP TABLE IF EXISTS `subcontractor_dispatch_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subcontractor_dispatch_requests` (
  `id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `service_provider_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `quote_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dispatch_response_eta` date DEFAULT NULL,
  `created_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `estimate_order_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estimate_appointment_start_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `transcription_request_created_by` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mark_up_percentage` double DEFAULT NULL,
  `quote_version_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_response` (`quote_id`),
  CONSTRAINT `subcontractor_dispatch_requests_ibfk_1` FOREIGN KEY (`quote_id`) REFERENCES `quotes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subcontractor_dispatch_requests`
--

LOCK TABLES `subcontractor_dispatch_requests` WRITE;
/*!40000 ALTER TABLE `subcontractor_dispatch_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `subcontractor_dispatch_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subcontractor_dispatch_responses`
--

DROP TABLE IF EXISTS `subcontractor_dispatch_responses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subcontractor_dispatch_responses` (
  `id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `minimum_down_payment` double DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `created_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dispatch_request_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `minimum_job_days` int(11) DEFAULT NULL,
  `maximum_job_days` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_response` (`dispatch_request_id`),
  CONSTRAINT `subcontractor_dispatch_responses_ibfk_1` FOREIGN KEY (`dispatch_request_id`) REFERENCES `subcontractor_dispatch_requests` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subcontractor_dispatch_responses`
--

LOCK TABLES `subcontractor_dispatch_responses` WRITE;
/*!40000 ALTER TABLE `subcontractor_dispatch_responses` DISABLE KEYS */;
/*!40000 ALTER TABLE `subcontractor_dispatch_responses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subcontractor_dispatch_uploads`
--

DROP TABLE IF EXISTS `subcontractor_dispatch_uploads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subcontractor_dispatch_uploads` (
  `id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `response_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location` text COLLATE utf8_unicode_ci,
  `created_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_response` (`response_id`),
  CONSTRAINT `subcontractor_dispatch_uploads_ibfk_1` FOREIGN KEY (`response_id`) REFERENCES `subcontractor_dispatch_responses` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subcontractor_dispatch_uploads`
--

LOCK TABLES `subcontractor_dispatch_uploads` WRITE;
/*!40000 ALTER TABLE `subcontractor_dispatch_uploads` DISABLE KEYS */;
/*!40000 ALTER TABLE `subcontractor_dispatch_uploads` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-10-01 10:35:44
